package main.kotlin

fun main(){

    /*

    if (kondisi boolean) {
        jika kondisi bernilai true maka isi blok if akan dieksekusi
    }

    */

    val examValue = 30

    if (examValue > 80) {
        println("NC1")
    }else if (examValue > 60) {
        println("Hehe Not Bad")
    }else {
        println("NT NT")
    }

}