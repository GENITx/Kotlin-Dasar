package main.kotlin

/*
* This is multi line comment
* */

fun main() {
//    this is single line comment
}