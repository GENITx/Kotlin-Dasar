package main.kotlin

fun main(){

    /*

    Operator        Keterangan
        +           Penjumlahan
        -           Pengurangan
        *           Perkalian
        /           Pembagian
        %           Sisa Pembagian


    */

    var result1 : Int = 10/3
    println(result1)

    var result2 : Int = 10 + 10 / 2
    println(result2)

    /*

    Augmented Assignments

    Operasi Matematika          Augmented Assignments
        a = a + 10                      a += 10
        a = a - 10                      a -= 10
        a = a * 10                      a *= 10
        a = a / 10                      a /= 10
        a = a % 10                      a %= 10


    */
}