package main.kotlin

fun main(args : Array<String>) {
    for (value in args) {
        println(value)
    }
}