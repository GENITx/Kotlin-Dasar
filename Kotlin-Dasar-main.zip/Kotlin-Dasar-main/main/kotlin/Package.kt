import eko.util.sayHello
//import eko.util

fun main(){
    sayHello("Eko")

    eko.util.sayHello("Eko", "Kurniawan")

    eko.util.sayHai("Moklet")
}