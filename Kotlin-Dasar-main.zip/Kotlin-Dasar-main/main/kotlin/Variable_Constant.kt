package main.kotlin

const val APP = "Belajar Kotlin"
const val VERSION = "0.0.1"

fun main(){
    println("Welcome to $APP version $VERSION")
}