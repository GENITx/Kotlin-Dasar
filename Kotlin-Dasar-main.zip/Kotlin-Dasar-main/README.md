# Kotlin-Dasar

Output Array

![Array](https://user-images.githubusercontent.com/101272430/199630085-2b28ae61-2a68-4e73-8930-569c8110d3e5.jpeg)

Output Closure

![Closure](https://user-images.githubusercontent.com/101272430/199630091-6700f89e-1eb4-48da-be23-397060f7cd9f.jpeg)

Output Factorial

![Factorial](https://user-images.githubusercontent.com/101272430/199630098-d5bfebc3-623f-4e19-8a17-1f897e0bf125.jpeg)

Output ForLoop

![ForLoop](https://user-images.githubusercontent.com/101272430/199630102-5175f030-f768-46f9-b82c-92ef85a89c5f.jpeg)

Output Function

![Function](https://user-images.githubusercontent.com/101272430/199630109-6f8f4746-375e-461b-bda9-bcc211f9fc67.jpeg)

Output Higher-Order_Functions

![Higher-Order_Functions](https://user-images.githubusercontent.com/101272430/199630114-71afdfbd-9d43-4cdf-a0b5-9315e28867a9.jpeg)

Output If

![If](https://user-images.githubusercontent.com/101272430/199630900-a48a7ac6-fd21-4d40-b68d-fb4d3a5d4ccf.jpeg)

Output Inline Function

![Inline Function](https://user-images.githubusercontent.com/101272430/199630897-75281f23-d0ff-426f-87b9-e9b530dcedca.jpeg)

Output Kotlin Dasar

![Kotlin Dasar](https://user-images.githubusercontent.com/101272430/199630890-eef408f4-9fcd-454a-a658-7c6e34a0a78e.jpeg)

Output Label

![Label](https://user-images.githubusercontent.com/101272430/199631913-4df6a568-9a70-47dd-9c3b-82fd001ff8dc.jpeg)

Output Lambda_Expression

![Lambda_Expression](https://user-images.githubusercontent.com/101272430/199631894-fe843df9-3b83-4de5-8a82-59c3a0eda758.jpeg)

Output Math

![Math](https://user-images.githubusercontent.com/101272430/199631896-086363a9-f782-4bdf-b206-380cc2cc3f0e.jpeg)

Output Package

![Package](https://user-images.githubusercontent.com/101272430/199631897-4887c1ef-7b65-4386-96d3-5db177543790.jpeg)

Output Range

![Range](https://user-images.githubusercontent.com/101272430/199631899-896234ed-f2ff-4531-9188-d8077e76c176.jpeg)

Output Tail Recursive

![Tail Recursive](https://user-images.githubusercontent.com/101272430/199631901-84dbd74c-71b0-47ca-a827-41f8cee377de.jpeg)

Output Variable Constant

![Variable Constant](https://user-images.githubusercontent.com/101272430/199631904-6f41b270-8a44-4041-97c6-a66c4c5d958c.jpeg)

Output When

![When](https://user-images.githubusercontent.com/101272430/199631908-5c019f6f-a6ac-4b2b-8460-d2236eb34c59.jpeg)

Output While

![While](https://user-images.githubusercontent.com/101272430/199631910-b3f2bcab-a903-4d91-882c-aa9dacb0f8b3.jpeg)
