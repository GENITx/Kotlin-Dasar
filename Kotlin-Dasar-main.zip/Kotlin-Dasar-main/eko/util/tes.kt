package eko.util

fun sayHai(name : String) {
    println("Hai $name")
}