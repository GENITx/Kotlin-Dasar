package eko.util
//import eko.util.sayHello

fun sayHello(name : String) {
    println("Hello $name")
}

fun sayHello(firstname : String, lastname : String) {
    println("Hello $firstname $lastname")
}